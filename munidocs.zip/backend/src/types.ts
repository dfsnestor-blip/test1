export type Role = 'admin' | 'secretario' | 'abogado' | 'director' | 'funcionario' | 'ciudadano';
